import * as THREE from 'three';
import { GLTF } from 'three-stdlib/loaders/GLTFLoader';

import { MeshSurfaceSampler } from "three-stdlib/math/MeshSurfaceSampler";
import { BasicScene } from "./basicscene";
import { addDecal } from './decals';

export { GameScene }

class GameScene extends BasicScene {

    constructor(path : string) {
        super(path);
    }
    
    loaderFunc(bs: BasicScene, gltf: GLTF) {
        super.loaderFunc(bs, gltf);
        console.log("GS load");

        const sampler = new MeshSurfaceSampler(this.mesh!).build();
        const pos = new THREE.Vector3();
        const norm = new THREE.Vector3();

        console.log(new THREE.Box3().setFromObject(this.scene?.children[0]!));

        const box = new THREE.BoxHelper( this.scene!.children[0], 0xffff00 );
        this.scene!.add( box );
        console.log(box);

        const normalTransform = new THREE.Matrix3().getNormalMatrix(this.mesh!.matrixWorld);

        for (let i = 0; i < 10; i++) {
            sampler.sample(pos, norm);
            this.mesh?.localToWorld(pos);
            norm.applyMatrix3(normalTransform).normalize();
            console.log(pos, norm);
            addDecal({ intersects: true, point: pos, normal: norm });
        }
    }

    
}