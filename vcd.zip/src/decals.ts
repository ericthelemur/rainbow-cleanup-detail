import * as THREE from 'three';
import { scene, player } from './index';
import { textureLoader } from './loader';
import { DecalGeometry } from 'three-stdlib/geometries/DecalGeometry';
export { decals, decalInit, addDecal };

let raycaster: THREE.Raycaster;
let line: THREE.Line;

type intersectionT = { intersects: boolean; point: THREE.Vector3; normal: THREE.Vector3 };

const mouse = new THREE.Vector2();

const decalDiffuse = textureLoader.load('decal-diffuse.png');
const decalNormal = textureLoader.load('decal-normal.jpg');

const decalMaterial = new THREE.MeshPhongMaterial({
    specular: 0x444444, shininess: 30,
    map: decalDiffuse, 
    normalMap: decalNormal, normalScale: new THREE.Vector2(1, 1),
    transparent: true, depthTest: true, depthWrite: false,
    polygonOffset: true, polygonOffsetFactor: -4, wireframe: false
});
const collMat = new THREE.MeshBasicMaterial();

const decals: THREE.Mesh[] = [];

type dirtT = { decal: THREE.Mesh, collider: THREE.Mesh }

const dirts = new Map<number, dirtT>();
const colliders : THREE.Group = new THREE.Group();

function decalInit () {
    raycaster = new THREE.Raycaster();

    scene.add(colliders);

    const geometry = new THREE.BufferGeometry();
    geometry.setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    line = new THREE.Line(geometry, new THREE.LineBasicMaterial({ color: 0xFF0000 }));
    scene.add(line);

    const positions = line.geometry.attributes.position;
    positions.setXYZ(0, 0, 0, 0);
    positions.setXYZ(1, 1, 0, 0);
    positions.needsUpdate = true;
    line.geometry.computeBoundingSphere();

    window.addEventListener('pointerup', function(event) {
        if (event.button == 0) splat();  
        else if (event.button == 2) clean();
    });
}


function checkIntersection (x: number, y: number): intersectionT {
    console.log(x, y);
    mouse.x = (x! / window.innerWidth) * 2 - 1;
    mouse.y = -(y! / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, player.camera);
    const intersects: THREE.Intersection[] = [];
    raycaster.intersectObjects(scene.scene?.children!, true, intersects);

    const intersection: intersectionT = { intersects: false, point: new THREE.Vector3(), normal: new THREE.Vector3() };
    if (intersects.length > 0) {
        const p = intersects[0].point;
        intersection.point.copy(p);

        intersection.normal.copy(intersects[0].face!.normal);
        intersection.normal.transformDirection(intersects[0].object.matrixWorld);

        intersection.intersects = true;
    }
    return intersection;
}

function addDecal(intersection: intersectionT) {
    const position = intersection.point.clone();
    // Use workaround with blank O3D to get Euler angles for decal projection
    const o = new THREE.Object3D();
    o.position.copy(intersection.point.clone().add(intersection.normal));
    o.lookAt(intersection.point);
    const orientation = o.rotation;

    orientation.z = Math.random() * 2 * Math.PI;

    const scale = 1 + Math.random() * (2 - 1);
    const size = new THREE.Vector3(scale, scale, 0.05);
    const material = decalMaterial.clone();
    material.color.setHex(Math.random() * 0xffffff);

    const m = new THREE.Mesh(
        new DecalGeometry(scene.scene?.children[0] as THREE.Mesh, position, orientation, size),
        material
    );

    decals.push(m);
    scene.add(m);

    const sph = new THREE.Mesh(new THREE.SphereGeometry(0.75), collMat);
    sph.visible = false;
    sph.position.set(position.x, position.y, position.z);
    
    dirts.set(sph.id, {decal: m, collider: sph});
    colliders.add(sph);

    console.log(m, sph);
}

function splat () {
    const intersection = checkIntersection(window.innerWidth/2, window.innerHeight/2);
    if (!intersection.intersects) return;
    console.log(intersection);
    addDecal(intersection);

    
    // const p = intersection.point.clone();
    // const n = intersection.normal.clone();
    // n.add(p);
    // const positions = line.geometry.attributes.position;
    // positions.setXYZ(0, p.x, p.y, p.z);
    // positions.setXYZ(1, n.x, n.y, n.z);
    // positions.needsUpdate = true;
    // line.geometry.computeBoundingSphere();
}

function clean() {
    mouse.x = (window.innerWidth/2 / window.innerWidth) * 2 - 1;
    mouse.y = -(window.innerHeight/2 / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, player.camera);
    const intersects: THREE.Intersection[] = [];
    raycaster.intersectObjects(colliders.children, true, intersects);

    if (intersects.length == 0 || intersects[0].distance > 0.5) return;

    const id = intersects[0].object.id;
    const dirt = dirts.get(id)!;

    colliders.remove(dirt.collider);
    scene.remove(dirt.decal);
    decals.filter(function(d) { return d == dirt.decal} )
    dirts.delete(id);
}

function removeDecals () {
    decals.forEach(function (d) {
        scene.remove(d);
    });

    decals.length = 0;
}

