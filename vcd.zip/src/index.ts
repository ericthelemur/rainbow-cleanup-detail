import * as THREE from 'three';
import { GLTFLoader } from 'three-stdlib/loaders/GLTFLoader';
import { Player } from './player';
import {Spheres} from './spheres';
import { BasicScene } from './basicscene';
import {decals, decalInit} from "./decals";
import { GameScene } from './gamescene';
export {GRAVITY, keyStates, renderer, scene, player }


const GRAVITY = 30;
const clock = new THREE.Clock();
const STEPS_PER_FRAME = 5;

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.VSMShadowMap;
renderer.toneMapping = THREE.ReinhardToneMapping;
renderer.toneMappingExposure = 2.2;
renderer.outputEncoding = THREE.sRGBEncoding;


const container = document.getElementById('container')!;
container.appendChild(renderer.domElement);

const keyStates: { [code: string]: boolean } = {};

document.addEventListener('keydown', (event: KeyboardEvent) => {
    keyStates[event.code] = true;
});

document.addEventListener('keyup', (event: KeyboardEvent) => {
    keyStates[event.code] = false;
});

window.addEventListener('resize', onWindowResize);

function onWindowResize () {
    player.camera.aspect = window.innerWidth / window.innerHeight;
    player.camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);
}

const scene = new GameScene("collision-world.glb");
Spheres.initSpheres();
const player = new Player();

decalInit();

function animate () {
    const deltaTime = Math.min(0.05, clock.getDelta()) / STEPS_PER_FRAME;

    // take collisions a step at a time
    for (let i = 0; i < STEPS_PER_FRAME; i++) {
        Spheres.updateSpheres(deltaTime);
        player.update(deltaTime);
    }

    renderer.render(scene, player.camera);
    requestAnimationFrame(animate);
}

animate();