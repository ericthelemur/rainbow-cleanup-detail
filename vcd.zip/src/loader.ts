import { TextureLoader } from 'three';
import { GLTFLoader } from 'three-stdlib/loaders/GLTFLoader';
export {MODEL_PATH, TEXTURE_PATH, modelLoader, textureLoader}

const RESOURCE_BASE = "../resources/"
const MODEL_PATH = RESOURCE_BASE + "models/";
const TEXTURE_PATH = RESOURCE_BASE + "textures/";

const modelLoader = new GLTFLoader().setPath(MODEL_PATH);
const textureLoader = new TextureLoader().setPath(TEXTURE_PATH);
