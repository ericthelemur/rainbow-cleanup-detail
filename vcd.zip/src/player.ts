
import * as THREE from 'three';
import { Material, MeshPhongMaterial, Object3D } from 'three';
import { Capsule } from 'three-stdlib/math/Capsule';
import { GRAVITY, keyStates, scene, player } from './index';
import { modelLoader, textureLoader, TEXTURE_PATH } from './loader';
import { Sphere, Spheres } from "./spheres";
export { Player };

class Player {
    head: THREE.Object3D;
    camera: THREE.PerspectiveCamera;
    collider: Capsule;

    velocity: THREE.Vector3;
    direction: THREE.Vector3;
    onFloor: boolean;

    mouseTime: number;
    mass: number = 50;
    brush: THREE.Mesh | null;

    constructor() {
        this.head = new THREE.Object3D();
        this.head.rotation.order = 'YXZ';
        scene.add(this.head);
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

        this.collider = new Capsule(new THREE.Vector3(0, 0.35, 0), new THREE.Vector3(0, 1, 0), 0.35);

        this.velocity = new THREE.Vector3();
        this.direction = new THREE.Vector3();

        this.onFloor = false;
        this.mouseTime = 0;

        document.addEventListener('mousedown', () => {
            document.body.requestPointerLock();
            // this.mouseTime = performance.now();
        });
    
        // document.addEventListener('mouseup', () => {
        //     Spheres.throwBall(this);
        // });
    
        document.body.addEventListener('mousemove', event => {
            if (document.pointerLockElement === document.body) {
                this.head.rotation.y -= event.movementX / 500;
                this.head.rotation.x -= event.movementY / 500;
            }
        });
        
        const CH_SIZE = "40px";
        const HALF_CH = "20px";
        // if (!document.getElementById("crosshair")) {
            var elem = document.createElement("img");
            elem.src = TEXTURE_PATH + "crosshair.png";
            elem.id = "crosshair";
            elem.style.position = "absolute";
            elem.style.width = CH_SIZE;
            elem.style.top = "calc(50% - " + HALF_CH + ")";
            elem.style.left = "calc(50% - " + HALF_CH + ")";
            elem.style.userSelect = "none";
            
            document.getElementById("container")!.appendChild(elem);
        // }

        this.brush = null;
        const p = this;
        
        const diffuse = textureLoader.load("brush/brush_img1.png");
        diffuse.encoding = THREE.sRGBEncoding;

        const material = new THREE.MeshStandardMaterial({map: diffuse, 
                                roughnessMap: textureLoader.load("brush/brush_img2.png"),
                                metalnessMap: textureLoader.load("brush/brush_img2.png"),
                                normalMap: textureLoader.load("brush/brush_img0.png")});
        
        const oldPath = modelLoader.path;
        modelLoader.setPath(oldPath + "Brush/");
        modelLoader.load("brush.gltf", function (gltf) {
            console.log("A");
            gltf.scene.traverse(child => {
                if (child.type == "Mesh") {
                    const m = child as THREE.Mesh;
                    m.receiveShadow = true;
                    m.material = material;
                }
            });
            console.log("B");
            p.brush = gltf.scene.getObjectByName("Brush")! as THREE.Mesh;
            p.brush.material = material;
            console.log("BRUSH", p.brush.material);

            scene.add(p.brush);
            p.brush.rotateZ(-Math.PI/6);
            p.brush.rotateX(Math.PI/2);
            p.brush.rotateY(Math.PI / 6);
            p.brush.translateY(-0.8);
            p.brush.translateX(0.4);
            p.brush.translateZ(0.2);
            // p.brush.position.set(0.1, 0.1, 0.1);
            p.head.add(p.brush);
            console.log("Loaded Brush");
            
            const c = p.brush!.clone();
            scene.add(c);
        });
        modelLoader.setPath(oldPath);
    }

    updateChildren() {
        this.camera.position.copy(this.head.position);
        this.camera.rotation.copy(this.head.rotation);
    }

    update(deltaTime: number) {
        this.controls(deltaTime);
        this.updatePlayer(deltaTime);
        this.teleportPlayerIfOob();
        
        for (const sphere of Spheres.spheres) {
            sphere.playerCollision(this);
        }

        this.updateChildren();
    }

    updatePlayer (deltaTime: number) {
        let damping = Math.exp(-8 * deltaTime) - 1;

        if (!this.onFloor) {
            this.velocity.y -= GRAVITY * deltaTime;

            // small air resistance
            damping *= 0.1;
        }

        this.velocity.addScaledVector(this.velocity, damping);
        const deltaPosition = this.velocity.clone().multiplyScalar(deltaTime);
        this.collider.translate(deltaPosition);

        this.collisions();

        this.head.position.copy(this.collider.end);

        if (this.brush) {
            this.brush.updateMatrixWorld();
        }
    }

    collisions () {
        const result = scene.worldOctree.capsuleIntersect(this.collider);
        this.onFloor = false;

        if (result) {
            this.onFloor = result.normal.y > 0;
            if (!this.onFloor) {
                this.velocity.addScaledVector(result.normal, -result.normal.dot(this.velocity));
            }
            this.collider.translate(result.normal.multiplyScalar(result.depth));
        }
    }
    
    teleportPlayerIfOob() {
        if (this.head.position.y <= -25) {
            this.collider.start.set(0, 0.35, 0);
            this.collider.end.set(0, 1, 0);
            this.collider.radius = 0.35;
            this.head.position.copy(this.collider.end);
            this.head.rotation.set(0, 0, 0);
        }
    }

    
    controls (deltaTime: number) {
        // gives a bit of air control
        const speedDelta = deltaTime * (this.onFloor ? 25 : 8);

        if (keyStates['KeyW']) { this.velocity.add(this.getForwardVector().multiplyScalar(speedDelta)); }
        if (keyStates['KeyS']) { this.velocity.add(this.getForwardVector().multiplyScalar(-speedDelta)); }
        if (keyStates['KeyA']) { this.velocity.add(this.getSideVector().multiplyScalar(-speedDelta)); }
        if (keyStates['KeyD']) { this.velocity.add(this.getSideVector().multiplyScalar(speedDelta)); }

        if (this.onFloor) {
            if (keyStates['Space']) {
                this.velocity.y = 15;
            }
        }
    }

    getForwardVector () {
        const looking = new THREE.Vector3();
        this.camera.getWorldDirection(looking);
        looking.y = 0;
        looking.normalize();

        return looking;
    }

    getSideVector () {
        return this.getForwardVector().cross(this.camera.up);
    }
}